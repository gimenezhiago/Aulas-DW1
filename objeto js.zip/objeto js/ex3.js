carro = {}

carro.marca = "Toyota"
carro.modelo = "Corolla"
carro.ano = "2020"

carro.cor = "preto"

delete carro.modelo

console.log(carro)