biblioteca = {
    titulo: [
        "O Senhor dos Anéis",
        "1984",
        "Orgulho e Preconceito"
    ],
    autor: [

    ],
    anoPublicacao: [

    ]
}

console.log(biblioteca.titulo)