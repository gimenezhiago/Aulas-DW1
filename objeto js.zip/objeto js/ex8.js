aluno = {
    nome: "Maria",
    idade: "16",
    curso: "Ciências da Computação"
}

const { nome, curso } = aluno

console.log(`Nome: ${nome}`);
console.log(`Curso: ${curso}`);