carro = {}

carro.marca = "Toyota"
carro.modelo = "Corolla"
carro.ano = "2020"

console.log(carro)