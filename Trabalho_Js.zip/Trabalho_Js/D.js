<h1>Escolha um número de 1 até 8:</h1>
let number = 8

switch (date) {
    case 0:

    case 1:
        console.log("1");
      break;
    case 2:
        console.log("2");
      break;
    case 3:
        console.log("3");
      break;
    case 4:
        console.log("4");
      break;
    case 5:
        console.log("5");
      break;
    case 6:
        console.log("6");
      break;
    case 7:
        console.log("7");
    break;
    case 8:
        console.log("8");
    break;
    default:
        console.log("Sem opção");
      break;
}