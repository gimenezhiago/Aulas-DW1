let condicao1 = false
let condicao2 = true
let condicao3 = true

console.log('1')
console.log('2')

if (condicao1 == true) {
    if (condicao3 == true) {
        console.log('A')
    } else {
        console.log('B')
    }
} else if (condicao2 == true) {
    console.log('C')
} else {
    console.log('D')
}

console.log('3')
console.log('4')